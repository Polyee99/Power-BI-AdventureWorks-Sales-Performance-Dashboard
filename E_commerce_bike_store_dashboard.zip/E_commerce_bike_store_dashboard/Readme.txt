1. This Microsoft Power BI file contains a complete online bike store dashboard with multiple pages, each focusing on different aspects of the store. The data used to create this dashboard is not real and is intended for educational purposes only.

2. To run this please make sure you are not changing the folder structure, otherwise the data connection will break and you will not be able to test every function of the dashboard.
